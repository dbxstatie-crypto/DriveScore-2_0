# DriveScore 2.0

Cardul cu câștig NET / km peste Bolt Driver.

## Cum obții APK-ul
**GitHub (fără Android Studio):** creezi un repo, urci tot conținutul acestui folder (inclusiv `.github`),
apoi la *Actions → Build APK → Run workflow*. După ~3 min descarci `DriveScore-apk` → `app-debug.apk`.

**Android Studio:** *File → Open* pe folder, apoi *Build → Build APK(s)*.

## Instalare
1. Prima dată dezinstalează vechiul DriveScore (e semnat cu altă cheie). Următoarele versiuni se instalează peste.
2. Deschide aplicația → apasă bannerul de sus → Accesibilitate → activează DriveScore.
   (Android 13+: Setări → Aplicații → DriveScore → ⋮ → „Permite setări restricționate”, apoi activezi.)
3. Din tabul Setări pui comisionul, consumul, prețul combustibilului etc. Simulatorul arată cardul live.

## Zone (v3)
Tabul **Zone**: apasă „Permite locația” și apoi „Permite tot timpul”. Aplicația notează locația la fiecare ofertă văzută și la fiecare cursă acceptată
și, după ~10 puncte, recomandă zonele (Centru, Nord etc.) pentru ziua și ora curentă. Datele rămân doar pe telefon.

Harta din tabul Zone folosește OpenStreetMap (osmdroid) și are nevoie de internet pentru străzi.
