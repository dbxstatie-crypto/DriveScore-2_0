package ro.drivescore

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** O cursă acceptată, salvată în istoric. */
data class Ride(
    val ts: Long,
    val price: Double,
    val pickupKm: Double,
    val tripKm: Double,
    val net: Double,
    val netPerKm: Double,
    val level: Level,
    val lat: Double = Double.NaN,
    val lon: Double = Double.NaN
) {
    val totalKm: Double get() = pickupKm + tripKm
}

object Store {
    private const val FILE = "drivescore"
    private const val K_HISTORY = "history"
    private const val K_DUMP = "dump"
    private const val K_OFFERS = "offers"
    private const val MAX_HISTORY = 1000

    private fun prefs(c: Context): SharedPreferences =
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ---------- setări ----------
    fun raw(c: Context, key: String): String? = prefs(c).getString(key, null)

    fun setRaw(c: Context, key: String, value: String) {
        prefs(c).edit().putString(key, value).apply()
    }

    fun config(c: Context): Config {
        val d = Config()
        fun g(k: String, def: Double): Double =
            prefs(c).getString(k, null)?.replace(',', '.')?.toDoubleOrNull() ?: def
        return Config(
            commissionPct = g("comm2", d.commissionPct),
            consumption = g("cons", d.consumption),
            energyPrice = g("eprice", d.energyPrice),
            maintPerKm = g("maint", d.maintPerKm),
            fixedMonthly = g("fix", d.fixedMonthly),
            kmPerWeek = g("kmw", d.kmPerWeek),
            greenNetPerKm = g("green2", d.greenNetPerKm),
            redNetPerKm = g("red2", d.redNetPerKm),
            shortKm = g("short", d.shortKm)
        )
    }

    // ---------- istoric ----------
    fun history(c: Context): List<Ride> {
        val s = prefs(c).getString(K_HISTORY, null) ?: return emptyList()
        val out = ArrayList<Ride>()
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Ride(
                        o.getLong("ts"), o.getDouble("price"), o.getDouble("pk"), o.getDouble("tk"),
                        o.getDouble("net"), o.getDouble("npk"),
                        Level.values()[o.getInt("lv").coerceIn(0, 2)],
                        o.optDouble("la", Double.NaN), o.optDouble("lo", Double.NaN)
                    )
                )
            }
        } catch (e: Exception) {
            // istoric corupt: îl ignorăm
        }
        return out
    }

    private fun save(c: Context, rides: List<Ride>) {
        val arr = JSONArray()
        for (r in rides.take(MAX_HISTORY)) {
            val jo = JSONObject()
                .put("ts", r.ts).put("price", r.price).put("pk", r.pickupKm).put("tk", r.tripKm)
                .put("net", r.net).put("npk", r.netPerKm).put("lv", r.level.ordinal)
            if (!r.lat.isNaN() && !r.lon.isNaN()) jo.put("la", r.lat).put("lo", r.lon)
            arr.put(jo)
        }
        prefs(c).edit().putString(K_HISTORY, arr.toString()).apply()
    }

    fun addRide(c: Context, o: Offer, r: Result, lat: Double? = null, lon: Double? = null) {
        val list = ArrayList<Ride>()
        list.add(
            Ride(
                System.currentTimeMillis(), o.price, o.pickupKm, o.tripKm, r.net, r.netPerKm, r.level,
                lat ?: Double.NaN, lon ?: Double.NaN
            )
        )
        list.addAll(history(c))
        save(c, list)
    }

    fun deleteRide(c: Context, ts: Long) {
        save(c, history(c).filter { it.ts != ts })
    }

    fun clearHistory(c: Context) {
        prefs(c).edit().remove(K_HISTORY).apply()
    }

    // ---------- oferte văzute (cerere pe zone): o linie pe ofertă "ts,lat,lon,net/km" ----------
    private const val MAX_OFFERS = 4000

    fun addOffer(c: Context, lat: Double, lon: Double, netPerKm: Double) {
        val line = System.currentTimeMillis().toString() + "," + lat + "," + lon + "," + netPerKm
        val old = prefs(c).getString(K_OFFERS, "") ?: ""
        val lines = if (old.isEmpty()) ArrayList<String>() else ArrayList(old.split("\n"))
        lines.add(line)
        val trimmed = if (lines.size > MAX_OFFERS) lines.subList(lines.size - MAX_OFFERS, lines.size) else lines
        prefs(c).edit().putString(K_OFFERS, trimmed.joinToString("\n")).apply()
    }

    fun clearOffers(c: Context) {
        prefs(c).edit().remove(K_OFFERS).apply()
    }

    /** Toate punctele cu locație: oferte văzute + curse acceptate. */
    fun geoEvents(c: Context): List<GeoEvent> {
        val out = ArrayList<GeoEvent>()
        val s = prefs(c).getString(K_OFFERS, "") ?: ""
        if (s.isNotEmpty()) {
            for (line in s.split("\n")) {
                val p = line.split(",")
                if (p.size < 4) continue
                val ts = p[0].toLongOrNull() ?: continue
                val la = p[1].toDoubleOrNull() ?: continue
                val lo = p[2].toDoubleOrNull() ?: continue
                out.add(GeoEvent(ts, la, lo, 0, p[3].toDoubleOrNull() ?: 0.0))
            }
        }
        for (r in history(c)) {
            if (!r.lat.isNaN() && !r.lon.isNaN()) out.add(GeoEvent(r.ts, r.lat, r.lon, 1, r.netPerKm))
        }
        return out
    }

    // ---------- diagnostic: ultimul text citat din aplicația de ride-hailing ----------
    fun setDump(c: Context, text: String) {
        prefs(c).edit().putString(K_DUMP, text).apply()
    }

    fun dump(c: Context): String = prefs(c).getString(K_DUMP, null) ?: ""
}
