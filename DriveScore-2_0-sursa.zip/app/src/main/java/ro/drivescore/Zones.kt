package ro.drivescore

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.view.View
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Un punct cu locație: kind 0 = ofertă văzută (cerere), kind 1 = cursă acceptată. */
data class GeoEvent(val ts: Long, val lat: Double, val lon: Double, val kind: Int, val netPerKm: Double)

data class Zone(
    val lat: Double,
    val lon: Double,
    val score: Double,
    val offers: Int,
    val rides: Int,
    val avgNetPerKm: Double
)

object Geo {
    fun hasPermission(c: Context): Boolean =
        c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun hasBackground(c: Context): Boolean =
        Build.VERSION.SDK_INT < 29 ||
            c.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Ultima locație cunoscută (max. 10 min vechime). */
    @Suppress("MissingPermission")
    fun last(c: Context): Pair<Double, Double>? {
        if (!hasPermission(c)) return null
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
        var best: Location? = null
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
            try {
                val l = lm.getLastKnownLocation(p) ?: continue
                val cur = best
                if (cur == null || l.time > cur.time) best = l
            } catch (e: Exception) {
                // provider indisponibil
            }
        }
        val b = best ?: return null
        if (System.currentTimeMillis() - b.time > 10 * 60 * 1000L) return null
        return Pair(b.latitude, b.longitude)
    }

    fun distKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2) * sin(dLon / 2)
        return 2 * r * atan2(sqrt(a), sqrt(1 - a))
    }

    /** Direcția de la (lat1,lon1) spre (lat2,lon2) ca nume: Nord, Nord-Est etc. */
    fun direction(lat1: Double, lon1: Double, lat2: Double, lon2: Double): String {
        val dy = lat2 - lat1
        val dx = (lon2 - lon1) * cos(Math.toRadians(lat1))
        var deg = Math.toDegrees(atan2(dx, dy)) // 0 = nord, 90 = est
        if (deg < 0) deg += 360.0
        val names = listOf("Nord", "Nord-Est", "Est", "Sud-Est", "Sud", "Sud-Vest", "Vest", "Nord-Vest")
        return names[(((deg + 22.5) / 45.0).toInt()) % 8]
    }
}

object Zones {
    const val CELL_DEG = 0.01 // ~1,1 km pe latitudine

    class Analysis(
        val zones: List<Zone>,      // sortate descrescător după scor
        val centerLat: Double,
        val centerLon: Double,
        val usedTimeFilter: Boolean,
        val lonStep: Double         // lățimea unei celule în grade de longitudine
    )

    private fun hourDiff(a: Int, b: Int): Int {
        val d = abs(a - b)
        return min(d, 24 - d)
    }

    fun analyze(all: List<GeoEvent>, nowMs: Long): Analysis? {
        if (all.isEmpty()) return null
        val cLat = all.sumOf { it.lat } / all.size
        val cLon = all.sumOf { it.lon } / all.size

        val now = Calendar.getInstance()
        now.timeInMillis = nowMs
        val hour = now.get(Calendar.HOUR_OF_DAY)
        val dow = now.get(Calendar.DAY_OF_WEEK)
        val weekend = dow == Calendar.SATURDAY || dow == Calendar.SUNDAY
        val cal = Calendar.getInstance()
        val sel = all.filter {
            cal.timeInMillis = it.ts
            val d = cal.get(Calendar.DAY_OF_WEEK)
            val we = d == Calendar.SATURDAY || d == Calendar.SUNDAY
            we == weekend && hourDiff(cal.get(Calendar.HOUR_OF_DAY), hour) <= 1
        }
        val useFilter = sel.size >= 12
        val data = if (useFilter) sel else all

        val lonStep = CELL_DEG / max(0.2, cos(Math.toRadians(cLat)))
        class Acc { var o = 0; var r = 0; var nsum = 0.0; var ln = 0 }
        val map = HashMap<String, Acc>()
        for (e in data) {
            val i = Math.floor(e.lat / CELL_DEG).toInt()
            val j = Math.floor(e.lon / lonStep).toInt()
            val a = map.getOrPut("$i:$j") { Acc() }
            if (e.kind == 1) { a.r++; a.nsum += e.netPerKm; a.ln++ } else a.o++
        }
        val zones = ArrayList<Zone>()
        for ((k, a) in map) {
            val p = k.split(":")
            val i = p[0].toInt()
            val j = p[1].toInt()
            zones.add(
                Zone(
                    (i + 0.5) * CELL_DEG, (j + 0.5) * lonStep,
                    a.o + 3.0 * a.r, a.o, a.r,
                    if (a.ln > 0) a.nsum / a.ln else 0.0
                )
            )
        }
        zones.sortByDescending { it.score }
        return Analysis(zones, cLat, cLon, useFilter, lonStep)
    }

    /** „Centru” dacă e aproape de centrul datelor tale, altfel direcția (Nord, Sud-Est etc.). */
    fun label(z: Zone, an: Analysis): String {
        val d = Geo.distKm(an.centerLat, an.centerLon, z.lat, z.lon)
        return if (d < 1.2) "Centru" else Geo.direction(an.centerLat, an.centerLon, z.lat, z.lon)
    }
}

/** Hartă simplă (fără străzi): pătrate de ~1 km colorate după câte oferte/curse au fost în zonă. */
class ZoneMapView(ctx: Context) : View(ctx) {
    var zones: List<Zone> = emptyList()
    var me: Pair<Double, Double>? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (zones.isEmpty()) return
        val half = Zones.CELL_DEG / 2
        var minLat = zones.minOf { it.lat } - half
        var maxLat = zones.maxOf { it.lat } + half
        val cosLat = max(0.2, cos(Math.toRadians((minLat + maxLat) / 2)))
        val lonHalf = half / cosLat
        var minLon = zones.minOf { it.lon } - lonHalf
        var maxLon = zones.maxOf { it.lon } + lonHalf
        me?.let {
            minLat = min(minLat, it.first); maxLat = max(maxLat, it.first)
            minLon = min(minLon, it.second); maxLon = max(maxLon, it.second)
        }
        val spanX = (maxLon - minLon) * cosLat
        val spanY = maxLat - minLat
        if (spanX <= 0.0 || spanY <= 0.0) return
        val pad = 12f * resources.displayMetrics.density
        val w = width - 2 * pad
        val h = height - 2 * pad
        val scale = min(w / spanX, h / spanY).toFloat()
        val offX = pad + (w - (spanX * scale).toFloat()) / 2f
        val offY = pad + (h - (spanY * scale).toFloat()) / 2f
        fun px(lon: Double): Float = offX + ((lon - minLon) * cosLat * scale).toFloat()
        fun py(lat: Double): Float = offY + ((maxLat - lat) * scale).toFloat()

        val maxScore = zones.maxOf { it.score }
        val side = (Zones.CELL_DEG * scale).toFloat()
        for ((idx, z) in zones.withIndex()) {
            val t = (z.score / maxScore).toFloat()
            p.style = Paint.Style.FILL
            p.color = Color.argb((50 + 205 * t).toInt(), 34, 197, 94)
            val cx = px(z.lon)
            val cy = py(z.lat)
            canvas.drawRect(cx - side / 2, cy - side / 2, cx + side / 2, cy + side / 2, p)
            if (idx < 3) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f * resources.displayMetrics.density
                p.color = Color.parseColor("#F5B301")
                canvas.drawRect(cx - side / 2, cy - side / 2, cx + side / 2, cy + side / 2, p)
            }
        }
        me?.let {
            val x = px(it.second)
            val y = py(it.first)
            p.style = Paint.Style.FILL
            p.color = Color.WHITE
            canvas.drawCircle(x, y, 8f * resources.displayMetrics.density, p)
            p.color = Color.parseColor("#3B82F6")
            canvas.drawCircle(x, y, 5f * resources.displayMetrics.density, p)
        }
    }
}
